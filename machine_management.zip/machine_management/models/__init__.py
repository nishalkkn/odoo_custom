from . import machine_management
from . import machine_part
from . import machine_service
from . import machine_tag
from . import machine_transfer
from . import machine_type
from . import res_partner
from . import machine_invoice
